# LiteOS Desktop Themes

Theme files are plain text and can be copied into the future LiteOS theme directory or hosted in a public theme repository.

Included presets:

- `brick-classic.theme`
- `red-classic.theme`
- `blue-steel.theme`
- `green-screen.theme`
- `high-contrast.theme`

The current GUI uses Brick Classic as its built-in default. Theme importing and live switching belong in the Settings app.
