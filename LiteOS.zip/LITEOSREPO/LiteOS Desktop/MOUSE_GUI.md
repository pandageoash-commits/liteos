# Mouse GUI

The first Mouse GUI is a lightweight VGA text-mode desktop.

- Brick Classic desktop colors
- Desktop icons for Shell, Files, LiteNano, Snake, and Settings
- Bottom taskbar with Start button
- PS/2 mouse cursor
- Left click opens an icon
- Escape or Q returns to the launcher

It intentionally avoids pixel graphics, transparency, and animation so it can run on old PCs. The screen and app callbacks are shared with the Keyboard GUI.
