# Kernel Integration Notes

The keyboard GUI is intentionally driver-agnostic. The kernel supplies four callbacks through `DesktopRuntime`:

- `clear()` clears the VGA screen.
- `write(text, color)` writes text using the terminal color format.
- `write_at(x, y, text, color)` draws at a fixed VGA text coordinate.
- `read_key()` returns LiteOS key codes.

The existing kernel can integrate it by exposing small wrappers around its current static terminal functions, then calling:

```c
DesktopRuntime runtime = {
    .clear = terminal_clear,
    .write = terminal_write_color,
    .write_at = terminal_write_at,
    .read_key = read_key
};
keyboard_gui_run(&runtime);
```

`terminal_write_at()` is the next small kernel-side helper. It should write directly to VGA memory without changing the normal shell cursor.

The selected item currently has no app dispatch because that belongs to the kernel command/application layer. The GUI module is responsible for navigation and drawing only.
