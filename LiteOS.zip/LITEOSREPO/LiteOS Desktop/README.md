# LiteOS Desktop

A lightweight text-mode desktop for LiteOS with two user-selectable interfaces:

1. Keyboard GUI: a two-pane file manager and application launcher.
2. Mouse GUI: a simple retro desktop with a taskbar, icons, and movable windows.

The first implementation targets VGA text mode and keyboard input. The mouse GUI will begin with PS/2 mouse support and simple pointer-driven controls.

The first keyboard GUI module is now in `src/keyboard_gui.c`. It provides the two-pane navigation screen, help view, selection movement, panel switching, and function-key bar through a small callback interface. See `INTEGRATION.md` for the kernel connection points.

## Design priorities

- Small memory footprint
- Fast on old computers
- Keyboard-first operation
- No external runtime dependencies
- Shared apps, files, themes, and settings
- Readable 16-color themes

## Current direction

The desktop starts with a launcher where the user chooses Keyboard GUI, Mouse GUI, or Shell. The first built-in theme is Brick Classic.
