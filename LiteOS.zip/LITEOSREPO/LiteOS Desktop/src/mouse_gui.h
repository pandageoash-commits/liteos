#ifndef LITEOS_MOUSE_GUI_H
#define LITEOS_MOUSE_GUI_H

#include "keyboard_gui.h"

typedef struct {
    int x;
    int y;
    int left_pressed;
    int right_pressed;
} DesktopMouseState;

typedef struct {
    DesktopRuntime common;
    void (*poll_mouse)(DesktopMouseState *state);
} MouseDesktopRuntime;

void mouse_gui_run(const MouseDesktopRuntime *runtime);

#endif
