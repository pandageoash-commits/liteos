#include "mouse_gui.h"

#define SCREEN_WIDTH 80
#define SCREEN_HEIGHT 25
#define DESKTOP_COLOR 0x4F
#define WINDOW_COLOR 0x70
#define TITLE_COLOR 0x4F
#define TASKBAR_COLOR 0x1F
#define CURSOR_COLOR 0x70

struct DesktopIcon {
    const char *label;
    const char *kind;
    int x;
    int y;
};

static const struct DesktopIcon icons[] = {
    {"Shell", "app", 5, 4},
        {"Files", "app", 18, 4},
    {"LiteNano", "app", 31, 4},
    {"Snake", "app", 44, 4},
    {"Settings", "app", 57, 4}
};

static void fill_line(const MouseDesktopRuntime *runtime, int y, desktop_u8 color) {
    char line[SCREEN_WIDTH + 1];
    for (int i = 0; i < SCREEN_WIDTH; i++) {
        line[i] = ' ';
    }
    line[SCREEN_WIDTH] = '\0';
    runtime->common.write_at(0, y, line, color);
}

static void draw_desktop(const MouseDesktopRuntime *runtime, const DesktopMouseState *mouse) {
    runtime->common.clear();
    for (int y = 0; y < SCREEN_HEIGHT - 1; y++) {
        fill_line(runtime, y, DESKTOP_COLOR);
    }

    runtime->common.write_at(2, 1, "LiteOS Desktop", DESKTOP_COLOR);
    for (unsigned int i = 0; i < sizeof(icons) / sizeof(icons[0]); i++) {
        runtime->common.write_at(icons[i].x, icons[i].y, "[ ]", WINDOW_COLOR);
        runtime->common.write_at(icons[i].x - 1, icons[i].y + 1, icons[i].label, DESKTOP_COLOR);
    }

    fill_line(runtime, SCREEN_HEIGHT - 1, TASKBAR_COLOR);
    runtime->common.write_at(1, SCREEN_HEIGHT - 1, "[ Start ]", TASKBAR_COLOR);
    runtime->common.write_at(64, SCREEN_HEIGHT - 1, "Mouse GUI", TASKBAR_COLOR);

    if (mouse->x >= 0 && mouse->x < SCREEN_WIDTH && mouse->y >= 0 && mouse->y < SCREEN_HEIGHT) {
        runtime->common.write_at(mouse->x, mouse->y, "X", CURSOR_COLOR);
    }
}

static int icon_at(int x, int y) {
    for (unsigned int i = 0; i < sizeof(icons) / sizeof(icons[0]); i++) {
        if (x >= icons[i].x - 1 && x <= icons[i].x + 3 && y >= icons[i].y && y <= icons[i].y + 1) {
            return (int)i;
        }
    }
    return -1;
}

static void show_about(const MouseDesktopRuntime *runtime) {
    runtime->common.clear();
    runtime->common.write_at(20, 8, "+------------------------+", TITLE_COLOR);
    runtime->common.write_at(20, 9, "| LiteOS Mouse GUI       |", TITLE_COLOR);
    runtime->common.write_at(20, 10, "| Lightweight desktop  |", WINDOW_COLOR);
    runtime->common.write_at(20, 11, "| Left click opens apps |", WINDOW_COLOR);
    runtime->common.write_at(20, 12, "+------------------------+", TITLE_COLOR);
    runtime->common.write_at(20, 14, "Click to return", TASKBAR_COLOR);
    while (1) {
        DesktopMouseState mouse = {40, 20, 0, 0};
        runtime->poll_mouse(&mouse);
        if (mouse.left_pressed || runtime->common.read_key() != 0) {
            return;
        }
    }
}

void mouse_gui_run(const MouseDesktopRuntime *runtime) {
    DesktopMouseState mouse = {40, 12, 0, 0};
    int previous_left = 0;

    while (1) {
        runtime->poll_mouse(&mouse);
        draw_desktop(runtime, &mouse);

        if (mouse.left_pressed && !previous_left) {
            int selected = icon_at(mouse.x, mouse.y);
            if (selected >= 0) {
                runtime->common.open_item(icons[selected].label, icons[selected].kind);
            } else if (mouse.y == SCREEN_HEIGHT - 1 && mouse.x < 12) {
                show_about(runtime);
            }
        }
        previous_left = mouse.left_pressed;

        int key = runtime->common.poll_key ? runtime->common.poll_key() : 0;
        if (key == 0x105 || key == 'q' || key == 'Q') {
            return;
        }
        if (runtime->common.sleep_ticks) {
            runtime->common.sleep_ticks(1);
        }
    }
}
