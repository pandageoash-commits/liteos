#ifndef LITEOS_KEYBOARD_GUI_H
#define LITEOS_KEYBOARD_GUI_H

typedef unsigned char desktop_u8;

typedef struct {
    void (*clear)(void);
    void (*write)(const char *text, desktop_u8 color);
    void (*write_at)(int x, int y, const char *text, desktop_u8 color);
    int (*read_key)(void);
    int (*poll_key)(void);
    void (*sleep_ticks)(unsigned int ticks);
    void (*open_item)(const char *name, const char *kind);
} DesktopRuntime;

void keyboard_gui_run(const DesktopRuntime *runtime);
void keyboard_gui_set_theme(int theme_id);

#endif
