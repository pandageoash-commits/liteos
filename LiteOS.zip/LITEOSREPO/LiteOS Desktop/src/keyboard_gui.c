#include "keyboard_gui.h"

#define KEY_UP 0x101
#define KEY_DOWN 0x102
#define KEY_LEFT 0x103
#define KEY_RIGHT 0x104
#define KEY_ESCAPE 0x105
#define KEY_ENTER '\n'
#define KEY_F1 0x201
#define KEY_F4 0x204
#define KEY_F10 0x210

static desktop_u8 color_panel = 0x1F;
static desktop_u8 color_panel_title = 0x1E;
static desktop_u8 color_selected = 0x70;
static desktop_u8 color_text = 0x07;
static desktop_u8 color_status = 0x70;

void keyboard_gui_set_theme(int theme_id) {
    if (theme_id == 1) {
        color_panel = 0x4F;
        color_panel_title = 0x4C;
        color_selected = 0x70;
        color_text = 0x07;
        color_status = 0x4F;
    } else if (theme_id == 2) {
        color_panel = 0x17;
        color_panel_title = 0x1F;
        color_selected = 0x70;
        color_text = 0x07;
        color_status = 0x17;
    } else if (theme_id == 3) {
        color_panel = 0x20;
        color_panel_title = 0x2A;
        color_selected = 0x70;
        color_text = 0x0A;
        color_status = 0x20;
    } else if (theme_id == 4) {
        color_panel = 0x70;
        color_panel_title = 0x70;
        color_selected = 0x07;
        color_text = 0x07;
        color_status = 0x70;
    } else {
        color_panel = 0x1F;
        color_panel_title = 0x1E;
        color_selected = 0x70;
        color_text = 0x07;
        color_status = 0x70;
    }
}

struct DesktopItem {
    const char *name;
    const char *kind;
};

static const struct DesktopItem items[] = {
    {"Shell", "app"},
    {"LiteNano", "app"},
    {"Snake", "app"},
    {"Settings", "app"},
    {"welcome.txt", "file"},
    {"hello.ls", "file"}
};

static void write_line(const DesktopRuntime *runtime, int y, const char *text, desktop_u8 color) {
    runtime->write_at(0, y, text, color);
}

static void draw_panel(const DesktopRuntime *runtime, int x, int width, int selected, int first_item) {
    char line[81];
    int item_count = (int)(sizeof(items) / sizeof(items[0]));

    for (int y = 2; y < 23; y++) {
        for (int i = 0; i < width && i < 80; i++) {
            line[i] = ' ';
        }
        line[width < 80 ? width : 80] = '\0';
        runtime->write_at(x, y, line, color_panel);
    }

    for (int i = 0; i < item_count && i < 19; i++) {
        int item_index = first_item + i;
        if (item_index >= item_count) {
            break;
        }
        desktop_u8 color = item_index == selected ? color_selected : color_panel;
        runtime->write_at(x + 2, 3 + i, items[item_index].name, color);
        runtime->write_at(x + width - 5, 3 + i, items[item_index].kind, color);
    }
}

static void draw_screen(const DesktopRuntime *runtime, int active_panel, int left_selected, int right_selected) {
    runtime->clear();
    write_line(runtime, 0, " LiteOS Keyboard GUI                                      Theme ", color_panel_title);
    write_line(runtime, 1, " /home/user                                      6 items", color_panel_title);
    draw_panel(runtime, 0, 39, active_panel == 0 ? left_selected : -1, 0);
    draw_panel(runtime, 41, 39, active_panel == 1 ? right_selected : -1, 0);
    write_line(runtime, 23, "F1 Help  F3 View  F4 Edit  F5 Copy  F6 Move  F8 Delete  F10 Menu", color_status);
    write_line(runtime, 24, "Tab: switch panel   Arrows: move   Enter: open   Esc: shell", color_status);
}

static void show_help(const DesktopRuntime *runtime) {
    runtime->clear();
    write_line(runtime, 1, "LiteOS Keyboard GUI - Help", 0x1E);
    write_line(runtime, 3, "Arrow keys   Move through files and applications", color_text);
    write_line(runtime, 4, "Tab          Switch between panels", color_text);
    write_line(runtime, 5, "Enter        Open the selected item", color_text);
    write_line(runtime, 6, "F4           Edit the selected file", color_text);
    write_line(runtime, 7, "F10          Open the main menu", color_text);
    write_line(runtime, 8, "Escape       Return to the LiteOS shell", color_text);
    write_line(runtime, 23, "Press any key to return", color_status);
    runtime->read_key();
}

void keyboard_gui_run(const DesktopRuntime *runtime) {
    int active_panel = 0;
    int left_selected = 0;
    int right_selected = 0;

    while (1) {
        draw_screen(runtime, active_panel, left_selected, right_selected);
        int key = runtime->read_key();

        if (key == KEY_ESCAPE) {
            return;
        }
        if (key == KEY_F1) {
            show_help(runtime);
            continue;
        }
        if (key == '\t') {
            active_panel = active_panel == 0 ? 1 : 0;
            continue;
        }
        if (key == KEY_UP) {
            if (active_panel == 0 && left_selected > 0) left_selected--;
            if (active_panel == 1 && right_selected > 0) right_selected--;
            continue;
        }
        if (key == KEY_DOWN) {
            if (active_panel == 0 && left_selected < 5) left_selected++;
            if (active_panel == 1 && right_selected < 5) right_selected++;
            continue;
        }
        if (key == KEY_F10) {
            return;
        }
        if (key == KEY_ENTER || key == KEY_F4) {
            int selected = active_panel == 0 ? left_selected : right_selected;
            if (runtime->open_item) {
                runtime->open_item(items[selected].name, items[selected].kind);
            }
            continue;
        }
    }
}
