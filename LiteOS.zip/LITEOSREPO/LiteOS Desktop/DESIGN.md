# LiteOS Desktop Design

## Startup launcher

```text
==================== LiteOS ====================

1. Keyboard GUI
2. Mouse GUI
3. Shell
4. Shutdown

Use arrows and Enter.
```

The selected mode should be stored in a future desktop configuration file, with the launcher remaining available through a settings action.

## Keyboard GUI

The keyboard interface is a two-pane text desktop inspired by classic DOS file managers, but with LiteOS-specific layout and shortcuts.

- Left and right file panels
- Highlighted selection bar
- Current path and file count
- Function-key command bar
- Apps: Terminal, Editor, Snake, Settings
- Tab switches panels
- Enter opens a file or app
- Escape returns to the previous screen

Suggested function keys:

- F1 Help
- F2 Rename
- F3 View
- F4 Edit
- F5 Copy
- F6 Move
- F7 New folder
- F8 Delete
- F10 Menu

## Mouse GUI

The mouse interface is a deliberately small retro desktop rather than a full modern window system.

- Solid-color desktop
- Taskbar at the bottom
- Start button and clock
- A few desktop icons
- Simple rectangular windows
- Title bars with close buttons
- No transparency, shadows, or animation
- Keyboard shortcuts remain available everywhere

The first pointer target is PS/2 mouse input. USB mouse support is a later hardware milestone.

## Shared applications

Both modes use the same application entry points:

- Terminal
- File manager
- LiteNano editor
- Snake
- Customization
- About LiteOS

## Theme format

Theme files are plain text and must be validated before applying:

```ini
name=Brick Classic
version=1
background=dark-red
window=light-gray
titlebar=brick-red
text=black
clock=on
```

Unknown keys should be ignored. Invalid values should fall back to the default theme.

Initial presets are stored in `themes/`:

- Brick Classic
- Red Classic
- Blue Steel
- Green Screen
- High Contrast

## Implementation stages

1. Shared launcher and screen state model
2. Keyboard GUI in VGA text mode
3. Theme parser and customization settings
4. PS/2 mouse driver
5. Mouse GUI pointer and window controls
6. Persistent settings and themes
