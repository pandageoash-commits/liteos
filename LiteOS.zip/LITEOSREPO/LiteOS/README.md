# LiteOS

LiteOS is a tiny 32-bit hobby operating system built for GRUB and QEMU. It includes a custom kernel, a shell, a simple nano-like editor, and a text-mode Snake game.

The kernel includes a PIT hardware timer and a first user-program layer. Programs are currently simple text files interpreted by the shell, which keeps the system small while providing a way to experiment with custom code.

## Build

```bash
make
```

## Run

```bash
make run
```

## USB keyboard support

LiteOS includes a minimal USB HID keyboard compatibility layer. It accepts USB keyboard reports through a small boot-protocol translator and falls back to the usual PS/2 path when needed. This is intentionally lightweight and is designed for educational kernels rather than full hardware-accelerated USB stacks.

## Commands

- help
- clear
- echo text
- ls
- cat filename
- edit filename
- run filename
- mousetest
- snake
- about

The shell also supports Up/Down command history and Tab completion for unique commands and filenames.

## Editor and display

LiteNano supports arrow-key cursor movement, insertion and deletion in the middle of a file, Ctrl+S save confirmation, and Ctrl+Q exit without saving. The VGA terminal has colored boot messages, prompts, and editor status text, plus scrolling.

## Custom programs

Create or edit a program with the built-in editor:

```text
edit hello.ls
```

Supported program commands are:

```text
print text to display
sleep seconds
wait
clear
```

Run it from the shell:

```text
run hello.ls
```

The built-in `hello.ls` file demonstrates the format. Files are currently stored in memory and reset when the OS reboots. Persistent files require a block-device driver and a disk-backed filesystem; the current ISO is read-only.

## Mouse testing

The stable `liteos-safe.iso` keeps the Mouse GUI disabled. Experimental builds include the `mousetest` shell command, which uses bounded PS/2 waits and reports whether a mouse responds, packet count, movement deltas, and button state. Press `Q` to stop the test.

Keep experimental images in `LiteOSTesting/mouse-tests/` and do not replace `liteos-safe.iso` until a test has survived on the target hardware.

## Hardware test notes

- Fujitsu Amilo Pro, Intel Pentium, 1 GB RAM: old stable LiteOS build worked correctly.
- Acer Aspire One netbook, 32-bit Intel Atom, 2 GB RAM: primary compatibility target for further mouse testing.

## Hardware roadmap

- The PIT timer is implemented and provides kernel ticks and sleep support.
- Persistent storage needs an ATA or AHCI driver plus a filesystem and a writable disk image.
- Real USB keyboard support needs USB host-controller discovery and an HID interrupt-transfer driver. The current USB layer is only a compatibility translator and does not discover USB hardware.
- The experimental Mouse GUI is temporarily disabled because PS/2 controller behavior varies on older hardware; the safe driver revision will use bounded waits and controller detection before enabling it again.
- Compiled user-mode ELF programs remain a later milestone after storage, process isolation, and system calls are available.

The project is intentionally small and educational. It is designed for experimentation and learning about low-level system programming.
