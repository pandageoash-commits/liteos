typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

#include "keyboard_gui.h"
#include "mouse_gui.h"

#define false 0
#define true 1

#define VGA_WIDTH 80
#define VGA_HEIGHT 25
#define VGA_MEMORY ((u8 *)0xB8000)
#define KEYBOARD_DATA_PORT 0x60
#define KEYBOARD_STATUS_PORT 0x64
#define MOUSE_COMMAND 0xD4
#define MOUSE_ENABLE 0xF4
#define PIC_MASTER_COMMAND 0x20
#define PIC_MASTER_DATA 0x21
#define PIC_SLAVE_COMMAND 0xA0
#define PIC_SLAVE_DATA 0xA1
#define PIT_COMMAND 0x43
#define PIT_CHANNEL0 0x40

#define USB_HID_KEYBOARD_PROTOCOL 0x01
#define USB_HID_MOD_LEFT_CTRL 0x01
#define USB_HID_MOD_LEFT_SHIFT 0x02
#define USB_HID_MOD_LEFT_ALT 0x04
#define USB_HID_MOD_LEFT_GUI 0x08

static int cursor_x = 0;
static int cursor_y = 0;
static u8 terminal_color = 0x07;
static char shell_buffer[256];
static int shell_len = 0;
static char shell_history[8][256];
static int shell_history_count = 0;
static int shell_history_index = 0;
static int keyboard_shift = 0;
static int keyboard_alt_gr = 0;
static int keyboard_ctrl = 0;
static int usb_keyboard_ready = 0;
static int usb_keyboard_queue[32];
static int usb_keyboard_queue_head = 0;
static int usb_keyboard_queue_tail = 0;
static volatile u32 timer_ticks = 0;
static int mouse_x = VGA_WIDTH / 2;
static int mouse_y = VGA_HEIGHT / 2;
static int mouse_left = 0;
static int mouse_right = 0;
static int mouse_packet_index = 0;
static u8 mouse_packet[3];
static u8 mouse_last_packet[3];
static int mouse_last_dx = 0;
static int mouse_last_dy = 0;
static int mouse_packet_count = 0;

struct IdtEntry {
    u16 base_low;
    u16 selector;
    u8 zero;
    u8 flags;
    u16 base_high;
} __attribute__((packed));

struct IdtPointer {
    u16 limit;
    u32 base;
} __attribute__((packed));

static struct IdtEntry idt[256];
static struct IdtPointer idt_pointer;

extern void timer_irq_stub(void);

static void memset(void *ptr, int value, u32 size);

struct File {
    char name[16];
    char content[512];
    int size;
    int exists;
};

static struct File files[16];
static int file_count = 0;

static void outb(u16 port, u8 value) {
    asm volatile("outb %0, %1" : : "a"(value), "Nd"(port));
}

static u8 inb(u16 port) {
    u8 value;
    asm volatile("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static void mouse_flush_data(void) {
    while ((inb(KEYBOARD_STATUS_PORT) & 0x01) != 0) {
        (void)inb(KEYBOARD_DATA_PORT);
    }
}

static int mouse_wait_input(void) {
    for (u32 timeout = 0; timeout < 100000; timeout++) {
        if ((inb(KEYBOARD_STATUS_PORT) & 0x02) == 0) {
            return 1;
        }
        asm volatile("pause");
    }
    return 0;
}

static int mouse_write(u8 value) {
    if (!mouse_wait_input()) {
        return 0;
    }
    outb(KEYBOARD_STATUS_PORT, MOUSE_COMMAND);
    if (!mouse_wait_input()) {
        return 0;
    }
    outb(KEYBOARD_DATA_PORT, value);
    return 1;
}

static int mouse_wait_ack(void) {
    for (u32 timeout = 0; timeout < 100000; timeout++) {
        if (inb(KEYBOARD_STATUS_PORT) & 0x01) {
            u8 status = inb(KEYBOARD_STATUS_PORT);
            u8 value = inb(KEYBOARD_DATA_PORT);
            if ((status & 0x20) != 0 && value == 0xFA) {
                return 1;
            }
            if ((status & 0x20) == 0) {
                continue;
            }
        }
        asm volatile("pause");
    }
    return 0;
}

static void mouse_disable(void) {
    mouse_write(0xF5);
    mouse_packet_index = 0;
    mouse_left = 0;
    mouse_right = 0;
}

static int mouse_begin_test(void) {
    mouse_packet_index = 0;
    mouse_packet_count = 0;
    mouse_last_dx = 0;
    mouse_last_dy = 0;
    mouse_flush_data();

    if (!mouse_wait_input()) {
        return 0;
    }

    outb(KEYBOARD_STATUS_PORT, 0xA7);
    asm volatile("pause");
    mouse_flush_data();

    outb(KEYBOARD_STATUS_PORT, 0xA8);
    asm volatile("pause");

    if (!mouse_write(0xF6) || !mouse_wait_ack()) {
        return 0;
    }

    if (!mouse_write(0xF4) || !mouse_wait_ack()) {
        mouse_disable();
        return 0;
    }

    return 1;
}

static void mouse_poll(DesktopMouseState *state) {
    while (inb(KEYBOARD_STATUS_PORT) & 0x01) {
        u8 status = inb(KEYBOARD_STATUS_PORT);
        if ((status & 0x20) == 0) {
            break;
        }
        u8 value = inb(KEYBOARD_DATA_PORT);

        if (mouse_packet_index == 0 && (value & 0x08) == 0) {
            continue;
        }
        mouse_packet[mouse_packet_index++] = value;
        if (mouse_packet_index == 3) {
            mouse_last_packet[0] = mouse_packet[0];
            mouse_last_packet[1] = mouse_packet[1];
            mouse_last_packet[2] = mouse_packet[2];

            int dx = (int)(signed char)mouse_packet[1];
            int dy = (int)(signed char)mouse_packet[2];
            mouse_last_dx = dx;
            mouse_last_dy = dy;
            mouse_packet_count++;
            mouse_x += dx;
            mouse_y -= dy;
            if (mouse_x < 0) mouse_x = 0;
            if (mouse_x >= VGA_WIDTH) mouse_x = VGA_WIDTH - 1;
            if (mouse_y < 0) mouse_y = 0;
            if (mouse_y >= VGA_HEIGHT - 1) mouse_y = VGA_HEIGHT - 2;
            mouse_left = mouse_packet[0] & 1;
            mouse_right = (mouse_packet[0] >> 1) & 1;
            mouse_packet_index = 0;
        }
    }

    state->x = mouse_x;
    state->y = mouse_y;
    state->left_pressed = mouse_left;
    state->right_pressed = mouse_right;
}

static void idt_set_gate(int number, u32 address, u16 selector) {
    idt[number].base_low = (u16)(address & 0xFFFF);
    idt[number].selector = selector;
    idt[number].zero = 0;
    idt[number].flags = 0x8E;
    idt[number].base_high = (u16)((address >> 16) & 0xFFFF);
}

void timer_irq_handler(void) {
    timer_ticks++;
    outb(PIC_MASTER_COMMAND, 0x20);
}

static void timer_init(void) {
    u16 divisor = 11931;
    u16 code_selector;

    memset(idt, 0, sizeof(idt));
    asm volatile("mov %%cs, %0" : "=r"(code_selector));
    idt_set_gate(32, (u32)timer_irq_stub, code_selector);
    idt_pointer.limit = sizeof(idt) - 1;
    idt_pointer.base = (u32)idt;

    outb(PIC_MASTER_COMMAND, 0x11);
    outb(PIC_SLAVE_COMMAND, 0x11);
    outb(PIC_MASTER_DATA, 0x20);
    outb(PIC_SLAVE_DATA, 0x28);
    outb(PIC_MASTER_DATA, 0x04);
    outb(PIC_SLAVE_DATA, 0x02);
    outb(PIC_MASTER_DATA, 0x01);
    outb(PIC_SLAVE_DATA, 0x01);

    outb(PIT_COMMAND, 0x36);
    outb(PIT_CHANNEL0, divisor & 0xFF);
    outb(PIT_CHANNEL0, divisor >> 8);

    asm volatile("lidtl %0" : : "m"(idt_pointer));
    outb(PIC_MASTER_DATA, 0xFE);
    outb(PIC_SLAVE_DATA, 0xFF);
    asm volatile("sti");
}

static void timer_sleep(u32 ticks) {
    u32 end = timer_ticks + ticks;
    while (timer_ticks < end) {
        asm volatile("hlt");
    }
}

static void memset(void *ptr, int value, u32 size) {
    u8 *p = (u8 *)ptr;
    for (u32 i = 0; i < size; i++) {
        p[i] = (u8)value;
    }
}

static void memcpy(void *dst, const void *src, u32 size) {
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    for (u32 i = 0; i < size; i++) {
        d[i] = s[i];
    }
}

static void memmove(void *dst, const void *src, u32 size) {
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    if (d < s) {
        for (u32 i = 0; i < size; i++) {
            d[i] = s[i];
        }
    } else if (d > s) {
        for (u32 i = size; i > 0; i--) {
            d[i - 1] = s[i - 1];
        }
    }
}

static int strlen(const char *s) {
    int len = 0;
    while (s[len] != '\0') {
        len++;
    }
    return len;
}

static void strcpy(char *dst, const char *src) {
    while ((*dst++ = *src++) != '\0') {
    }
}

static int strcmp(const char *a, const char *b) {
    while (*a && *b && *a == *b) {
        a++;
        b++;
    }
    return *a - *b;
}

static int strncmp(const char *a, const char *b, int n) {
    for (int i = 0; i < n; i++) {
        if (a[i] != b[i]) {
            return a[i] - b[i];
        }
        if (a[i] == '\0') {
            return 0;
        }
    }
    return 0;
}

static void scroll_up(void) {
    u8 *vga = VGA_MEMORY;
    for (int y = 1; y < VGA_HEIGHT; y++) {
        for (int x = 0; x < VGA_WIDTH; x++) {
            u8 *src = vga + (y * VGA_WIDTH + x) * 2;
            u8 *dst = vga + ((y - 1) * VGA_WIDTH + x) * 2;
            dst[0] = src[0];
            dst[1] = src[1];
        }
    }

    for (int x = 0; x < VGA_WIDTH; x++) {
        u8 *cell = vga + ((VGA_HEIGHT - 1) * VGA_WIDTH + x) * 2;
        cell[0] = ' ';
            cell[1] = terminal_color;
    }
    cursor_y = VGA_HEIGHT - 1;
}

static void terminal_putc(char c) {
    u8 *vga = VGA_MEMORY;

    if (c == '\n') {
        cursor_x = 0;
        cursor_y++;
    } else if (c == '\r') {
        cursor_x = 0;
    } else if (c == '\b') {
        if (cursor_x > 0) {
            cursor_x--;
            int index = (cursor_y * VGA_WIDTH + cursor_x) * 2;
            vga[index] = ' ';
            vga[index + 1] = terminal_color;
        }
    } else if (c == '\t') {
        for (int i = 0; i < 4; i++) {
            terminal_putc(' ');
        }
    } else {
        int index = (cursor_y * VGA_WIDTH + cursor_x) * 2;
        vga[index] = (u8)c;
        vga[index + 1] = terminal_color;
        cursor_x++;
    }

    if (cursor_x >= VGA_WIDTH) {
        cursor_x = 0;
        cursor_y++;
    }

    if (cursor_y >= VGA_HEIGHT) {
        scroll_up();
    }
}

static void terminal_write(const char *text) {
    while (*text) {
        terminal_putc(*text++);
    }
}

static void terminal_set_color(u8 color) {
    terminal_color = color;
}

static void terminal_write_color(const char *text, u8 color) {
    u8 old_color = terminal_color;
    terminal_set_color(color);
    terminal_write(text);
    terminal_set_color(old_color);
}

static void terminal_write_at(int x, int y, const char *text, u8 color) {
    u8 *vga = VGA_MEMORY;
    if (x < 0 || x >= VGA_WIDTH || y < 0 || y >= VGA_HEIGHT) {
        return;
    }

    while (*text && x < VGA_WIDTH) {
        int index = (y * VGA_WIDTH + x) * 2;
        vga[index] = (u8)*text++;
        vga[index + 1] = color;
        x++;
    }
}

static void terminal_clear(void) {
    memset((void *)VGA_MEMORY, 0, VGA_WIDTH * VGA_HEIGHT * 2);
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) {
        ((u8 *)VGA_MEMORY)[i * 2 + 1] = terminal_color;
    }
    cursor_x = 0;
    cursor_y = 0;
}

static void terminal_println(const char *text) {
    terminal_write(text);
    terminal_putc('\n');
}

static void terminal_print_dec(u32 value) {
    char buf[16];
    int pos = 0;
    if (value == 0) {
        terminal_putc('0');
        return;
    }
    while (value > 0) {
        buf[pos++] = '0' + (value % 10);
        value /= 10;
    }
    for (int i = pos - 1; i >= 0; i--) {
        terminal_putc(buf[i]);
    }
}

static void read_key_buffer(char *buf, int *len, int max_len) {
    while (1) {
        while ((inb(KEYBOARD_STATUS_PORT) & 0x01) == 0) {
            asm volatile("pause");
        }

        u8 code = inb(KEYBOARD_DATA_PORT);
        if (code == 0xE0) {
            continue;
        }

        if (code & 0x80) {
            continue;
        }

        if (code == 0x1C) {
            terminal_putc('\n');
            return;
        }

        if (code == 0x0E) {
            if (*len > 0) {
                (*len)--;
                buf[*len] = '\0';
                terminal_putc('\b');
                terminal_putc(' ');
                terminal_putc('\b');
            }
            continue;
        }

        if (code == 0x39) {
            continue;
        }

        if (code >= 0x02 && code <= 0x0C) {
            const char letters[] = "1234567890-=";
            char c = letters[code - 0x02];
            if (*len < max_len - 1) {
                buf[(*len)++] = c;
                buf[*len] = '\0';
                terminal_putc(c);
            }
            continue;
        }

        if (code >= 0x10 && code <= 0x19) {
            const char letters[] = "qwertyuiop";
            char c = letters[code - 0x10];
            if (*len < max_len - 1) {
                buf[(*len)++] = c;
                buf[*len] = '\0';
                terminal_putc(c);
            }
            continue;
        }

        if (code >= 0x1E && code <= 0x26) {
            const char letters[] = "asdfghjkl";
            char c = letters[code - 0x1E];
            if (*len < max_len - 1) {
                buf[(*len)++] = c;
                buf[*len] = '\0';
                terminal_putc(c);
            }
            continue;
        }

        if (code >= 0x2C && code <= 0x32) {
            const char letters[] = "zxcvbnm";
            char c = letters[code - 0x2C];
            if (*len < max_len - 1) {
                buf[(*len)++] = c;
                buf[*len] = '\0';
                terminal_putc(c);
            }
            continue;
        }

        if (code == 0x20) {
            if (*len < max_len - 1) {
                buf[(*len)++] = ' ';
                buf[*len] = '\0';
                terminal_putc(' ');
            }
        }
    }
}

static int read_char(void) {
    while ((inb(KEYBOARD_STATUS_PORT) & 0x01) == 0) {
        asm volatile("pause");
    }
    return inb(KEYBOARD_DATA_PORT);
}

static void usb_keyboard_queue_push(int value) {
    usb_keyboard_queue[usb_keyboard_queue_tail] = value;
    usb_keyboard_queue_tail = (usb_keyboard_queue_tail + 1) % 32;
}

static int usb_keyboard_queue_pop(void) {
    if (usb_keyboard_queue_head == usb_keyboard_queue_tail) {
        return 0;
    }
    int value = usb_keyboard_queue[usb_keyboard_queue_head];
    usb_keyboard_queue_head = (usb_keyboard_queue_head + 1) % 32;
    return value;
}

static char usb_hid_keycode_to_ascii(u8 keycode, int shift) {
    static const char lower[] = "abcdefghijklmnopqrstuvwxyz";
    static const char upper[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static const char digits[] = "1234567890";

    if (keycode >= 0x04 && keycode <= 0x1d) {
        int index = keycode - 0x04;
        return shift ? upper[index] : lower[index];
    }

    if (keycode >= 0x1e && keycode <= 0x27) {
        int index = keycode - 0x1e;
        return digits[index];
    }

    if (keycode == 0x28) {
        return '\n';
    }

    if (keycode == 0x2c) {
        return ' ';
    }

    if (keycode == 0x2d) {
        return '-';
    }

    if (keycode == 0x2e) {
        return '=';
    }

    if (keycode == 0x2f) {
        return '[';
    }

    if (keycode == 0x30) {
        return ']';
    }

    if (keycode == 0x31) {
        return '\\';
    }

    if (keycode == 0x33) {
        return ';';
    }

    if (keycode == 0x34) {
        return '\'';
    }

    if (keycode == 0x35) {
        return '`';
    }

    if (keycode == 0x36) {
        return ',';
    }

    if (keycode == 0x37) {
        return '.';
    }

    if (keycode == 0x38) {
        return '/';
    }

    if (keycode == 0x39) {
        return ' ';
    }

    return 0;
}

static void usb_keyboard_init(void) {
    usb_keyboard_ready = 0;
    usb_keyboard_queue_head = 0;
    usb_keyboard_queue_tail = 0;
}

static int usb_keyboard_poll(void) {
    if (!usb_keyboard_ready) {
        return 0;
    }

    if (usb_keyboard_queue_head != usb_keyboard_queue_tail) {
        return usb_keyboard_queue_pop();
    }

    return 0;
}

static int usb_keyboard_process_report(const u8 *report, int report_size) {
    if (report_size < 8) {
        return 0;
    }

    int shift = (report[0] & USB_HID_MOD_LEFT_SHIFT) != 0;
    int key_count = 0;

    for (int i = 2; i < 8 && i < report_size; i++) {
        if (report[i] == 0) {
            continue;
        }
        char c = usb_hid_keycode_to_ascii(report[i], shift);
        if (c != 0) {
            usb_keyboard_queue_push((int)c);
            key_count++;
        }
    }

    if (key_count > 0) {
        return 1;
    }

    return 0;
}

static int read_key(void) {
    int usb_key = usb_keyboard_poll();
    if (usb_key != 0) {
        return usb_key;
    }

    while (1) {
        int code = read_char();

        if (code == 0x2A || code == 0x36) {
            keyboard_shift = 1;
            continue;
        }
        if (code == 0xAA || code == 0xB6) {
            keyboard_shift = 0;
            continue;
        }
        if (code == 0x38) {
            keyboard_alt_gr = 1;
            continue;
        }
        if (code == 0xB8) {
            keyboard_alt_gr = 0;
            continue;
        }
        if (code == 0x1D) {
            keyboard_ctrl = 1;
            continue;
        }
        if (code == 0x9D) {
            keyboard_ctrl = 0;
            continue;
        }
        if (code == 0x3A) {
            continue;
        }
        if (code & 0x80) {
            continue;
        }

        if (code == 0x1C) {
            return '\n';
        }
        if (code == 0x0E) {
            return '\b';
        }
        if (code == 0x0F) {
            return '\t';
        }
        if (keyboard_ctrl && code == 0x1F) {
            return 0x13;
        }
        if (keyboard_ctrl && code == 0x10) {
            return 0x11;
        }
        if (code == 0x48) {
            return 0x100 + 1;
        }
        if (code == 0x50) {
            return 0x100 + 2;
        }
        if (code == 0x4B) {
            return 0x100 + 3;
        }
        if (code == 0x4D) {
            return 0x100 + 4;
        }
        if (code == 0x39) {
            return ' ';
        }

        if (code >= 0x02 && code <= 0x0C) {
            const char digits[] = "1234567890";
            const char digits_shift[] = "!\"#$%&'()*+";
            if (keyboard_shift) {
                return digits_shift[code - 0x02];
            }
            return digits[code - 0x02];
        }

        if (code == 0x0D) {
            return keyboard_shift ? '+' : '=';
        }

        if (code >= 0x10 && code <= 0x19) {
            const char letters[] = "qwertyuiop";
            const char letters_shift[] = "QWERTYUIOP";
            return keyboard_shift ? letters_shift[code - 0x10] : letters[code - 0x10];
        }

        if (code == 0x1A) {
            return keyboard_shift ? (char)0xDA : (char)0xFA;
        }
        if (code == 0x1B) {
            return keyboard_shift ? (char)0x8D : (char)0x8C;
        }
        if (code == 0x27) {
            return keyboard_shift ? (char)0x8A : (char)0x89;
        }

        if (code >= 0x1E && code <= 0x26) {
            const char letters[] = "asdfghjkl";
            const char letters_shift[] = "ASDFGHJKL";
            return keyboard_shift ? letters_shift[code - 0x1E] : letters[code - 0x1E];
        }

        if (code == 0x28) {
            return keyboard_shift ? (char)0x8E : (char)0x8F;
        }
        if (code == 0x2B) {
            return keyboard_shift ? '|' : '\\';
        }

        if (code >= 0x2C && code <= 0x32) {
            const char letters[] = "zxcvbnm";
            const char letters_shift[] = "ZXCVBNM";
            return keyboard_shift ? letters_shift[code - 0x2C] : letters[code - 0x2C];
        }

        if (code == 0x33) {
            return keyboard_shift ? ';' : ',';
        }
        if (code == 0x34) {
            return keyboard_shift ? ':' : '.';
        }
        if (code == 0x35) {
            return keyboard_shift ? '_' : '-';
        }
        if (code == 0x37) {
            return keyboard_shift ? '>' : '.';
        }
        if (code == 0x38) {
            return keyboard_shift ? '<' : ',';
        }
        if (code == 0x39) {
            return keyboard_shift ? '?' : '/';
        }

        return 0;
    }
}

static int poll_key(void) {
    int usb_key = usb_keyboard_poll();
    if (usb_key != 0) {
        return usb_key;
    }
    if ((inb(KEYBOARD_STATUS_PORT) & 0x01) == 0) {
        return 0;
    }
    return read_key();
}

static void mouse_test(void) {
    terminal_clear();
    terminal_println("LiteOS mouse diagnostic");
    terminal_println("Testing the PS/2-compatible mouse channel...");

    if (!mouse_begin_test()) {
        terminal_println("Mouse was not detected or did not respond.");
        terminal_println("No mouse GUI was started. Press any key to return.");
        read_key();
        return;
    }

    terminal_println("Mouse responded. Move it and click buttons.");
    terminal_println("Press Q to stop the test.");
    while (1) {
        DesktopMouseState state;
        mouse_poll(&state);
        terminal_clear();
        terminal_println("LiteOS mouse diagnostic");
        terminal_println("Move the mouse or click a button.");
        terminal_write("Packets: ");
        terminal_print_dec((u32)mouse_packet_count);
        terminal_write("  Raw: ");
        terminal_print_dec((u32)mouse_last_packet[0]);
        terminal_write(" ");
        terminal_print_dec((u32)mouse_last_packet[1]);
        terminal_write(" ");
        terminal_print_dec((u32)mouse_last_packet[2]);
        terminal_write("  X: ");
        terminal_print_dec((u32)state.x);
        terminal_write("  Y: ");
        terminal_print_dec((u32)state.y);
        terminal_write("  Last dx: ");
        terminal_print_dec((u32)(mouse_last_dx < 0 ? -mouse_last_dx : mouse_last_dx));
        terminal_write("  Last dy: ");
        terminal_print_dec((u32)(mouse_last_dy < 0 ? -mouse_last_dy : mouse_last_dy));
        terminal_putc('\n');
        terminal_write("Buttons: left=");
        terminal_putc(state.left_pressed ? '1' : '0');
        terminal_write(" right=");
        terminal_putc(state.right_pressed ? '1' : '0');
        terminal_putc('\n');
        terminal_println("Press Q to stop.");

        int key = poll_key();
        if (key == 'q' || key == 'Q') {
            mouse_disable();
            terminal_println("Mouse test stopped.");
            return;
        }
        timer_sleep(2);
    }
}

static void add_file_entry(const char *name, const char *content) {
    if (file_count >= 16) {
        return;
    }
    struct File *f = &files[file_count++];
    memset(f, 0, sizeof(*f));
    int name_len = strlen(name);
    if (name_len > 15) {
        name_len = 15;
    }
    memcpy(f->name, name, name_len);
    f->name[name_len] = '\0';
    f->exists = 1;
    int content_len = strlen(content);
    if (content_len > 511) {
        content_len = 511;
    }
    memcpy(f->content, content, content_len);
    f->content[content_len] = '\0';
    f->size = content_len;
}

static void init_filesystem(void) {
    add_file_entry("welcome.txt", "Welcome to LiteOS!\nThis tiny OS includes a shell, a nano-like text editor, and a Snake game.\n");
    add_file_entry("help.txt", "Commands: help, clear, echo, ls, cat, edit, run, snake, about\n");
    add_file_entry("notes.txt", "Try: edit notes.txt\nThen press Ctrl+S to save.\n");
    add_file_entry("hello.ls", "print Hello from a custom LiteOS program!\nsleep 1\nprint This file was executed by the shell.\n");
}

static struct File *find_file(const char *name) {
    for (int i = 0; i < file_count; i++) {
        if (strcmp(files[i].name, name) == 0) {
            return &files[i];
        }
    }
    return 0;
}

static void print_file_list(void) {
    terminal_println("Files:");
    for (int i = 0; i < file_count; i++) {
        terminal_write(files[i].name);
        terminal_putc('\n');
    }
}

static void cat_file(const char *name) {
    struct File *f = find_file(name);
    if (!f) {
        terminal_println("File not found.");
        return;
    }
    terminal_write(f->content);
    if (f->content[f->size - 1] != '\n') {
        terminal_putc('\n');
    }
}

static void save_file(const char *name, const char *content) {
    struct File *f = find_file(name);
    if (!f) {
        if (file_count >= 16) {
            terminal_println("File system is full.");
            return;
        }
        add_file_entry(name, content);
        terminal_println("File created.");
        return;
    }

    int len = strlen(content);
    if (len > 511) {
        len = 511;
    }
    memcpy(f->content, content, len);
    f->content[len] = '\0';
    f->size = len;
    terminal_println("File saved.");
}

static void program_write(const char *text) {
    terminal_write(text);
}

static int program_read_key(void) {
    return read_key();
}

static int program_number(const char *text) {
    int value = 0;
    while (*text >= '0' && *text <= '9') {
        value = value * 10 + (*text - '0');
        text++;
    }
    return value;
}

static void run_program(const char *name) {
    struct File *f = find_file(name);
    if (!f) {
        terminal_println("Program not found.");
        return;
    }

    char line[128];
    int line_len = 0;
    for (int i = 0; i <= f->size; i++) {
        char c = i < f->size ? f->content[i] : '\n';
        if (c != '\n' && line_len < 127) {
            line[line_len++] = c;
            continue;
        }

        line[line_len] = '\0';
        if (strncmp(line, "print ", 6) == 0) {
            program_write(line + 6);
            terminal_putc('\n');
        } else if (strcmp(line, "clear") == 0) {
            terminal_clear();
        } else if (strncmp(line, "sleep ", 6) == 0) {
            timer_sleep((u32)program_number(line + 6) * 10);
        } else if (strcmp(line, "wait") == 0) {
            program_read_key();
        } else if (line_len != 0) {
            terminal_write("Unknown program command: ");
            terminal_println(line);
        }
        line_len = 0;
    }
}

static int editor_line_start(const char *buffer, int cursor_pos) {
    while (cursor_pos > 0 && buffer[cursor_pos - 1] != '\n') {
        cursor_pos--;
    }
    return cursor_pos;
}

static int editor_line_end(const char *buffer, int len, int cursor_pos) {
    while (cursor_pos < len && buffer[cursor_pos] != '\n') {
        cursor_pos++;
    }
    return cursor_pos;
}

static void draw_editor_screen(const char *filename, const char *buffer, int len, int cursor_pos) {
    terminal_clear();
    terminal_write_color("LiteNano editor\n", 0x0B);
    terminal_write_color("File: ", 0x0E);
    terminal_println(filename);
    terminal_write_color("Ctrl+S save   Ctrl+Q quit   Arrows move\n", 0x07);
    terminal_putc('\n');

    int visible = 0;
    for (int i = 0; i < len && visible < 18; i++) {
        char c = buffer[i];
        if (c == '\n') {
            terminal_putc('\n');
            visible++;
        } else {
            terminal_putc(c);
            visible++;
        }
    }

    if (cursor_pos >= 0) {
        terminal_write_color("\n\nCursor pos: ", 0x0E);
        terminal_print_dec((u32)cursor_pos);
        terminal_write("  Ctrl+S saves changes\n");
    }
}

static void nano_editor(const char *filename) {
    char buffer[512];
    int len = 0;
    memset(buffer, 0, sizeof(buffer));

    struct File *f = find_file(filename);
    if (f) {
        len = f->size;
        memcpy(buffer, f->content, (u32)len);
        buffer[len] = '\0';
    }

    int cursor_pos = 0;
    draw_editor_screen(filename, buffer, len, cursor_pos);

    while (1) {
        int key = read_key();
        if (key == 0x13) {
            save_file(filename, buffer);
            return;
        }
        if (key == 0x11) {
            terminal_println("Editor closed without saving.");
            return;
        }

        if (key == '\b') {
            if (cursor_pos > 0) {
                memmove(buffer + cursor_pos - 1, buffer + cursor_pos, (u32)(len - cursor_pos));
                cursor_pos--;
                len--;
                buffer[len] = '\0';
                draw_editor_screen(filename, buffer, len, cursor_pos);
            }
            continue;
        }

        if (key == 0x100 + 3 && cursor_pos > 0) {
            cursor_pos--;
            draw_editor_screen(filename, buffer, len, cursor_pos);
            continue;
        }
        if (key == 0x100 + 4 && cursor_pos < len) {
            cursor_pos++;
            draw_editor_screen(filename, buffer, len, cursor_pos);
            continue;
        }
        if (key == 0x100 + 1) {
            int current_start = editor_line_start(buffer, cursor_pos);
            int column = cursor_pos - current_start;
            if (current_start > 0) {
                int previous_end = current_start - 1;
                int previous_start = editor_line_start(buffer, previous_end);
                int previous_length = previous_end - previous_start;
                cursor_pos = previous_start + (column < previous_length ? column : previous_length);
                draw_editor_screen(filename, buffer, len, cursor_pos);
            }
            continue;
        }
        if (key == 0x100 + 2) {
            int current_start = editor_line_start(buffer, cursor_pos);
            int column = cursor_pos - current_start;
            int current_end = editor_line_end(buffer, len, cursor_pos);
            if (current_end < len) {
                int next_start = current_end + 1;
                int next_end = editor_line_end(buffer, len, next_start);
                int next_length = next_end - next_start;
                cursor_pos = next_start + (column < next_length ? column : next_length);
                draw_editor_screen(filename, buffer, len, cursor_pos);
            }
            continue;
        }

        if (key == '\n') {
            if (len < 511) {
                memmove(buffer + cursor_pos + 1, buffer + cursor_pos, (u32)(len - cursor_pos));
                buffer[cursor_pos++] = '\n';
                len++;
                buffer[len] = '\0';
                draw_editor_screen(filename, buffer, len, cursor_pos);
            }
            continue;
        }

        if (key >= 32 && key < 127) {
            if (len < 511) {
                memmove(buffer + cursor_pos + 1, buffer + cursor_pos, (u32)(len - cursor_pos));
                buffer[cursor_pos++] = (char)key;
                len++;
                buffer[len] = '\0';
                draw_editor_screen(filename, buffer, len, cursor_pos);
            }
        }
    }
}

static void snake_game(void) {
    terminal_clear();
    terminal_println("LiteOS Snake");
    terminal_println("Arrow keys move, Q quits");

    const int width = 20;
    const int height = 12;
    int board[12][20];
    int snake_x[64];
    int snake_y[64];
    int length = 4;
    int dir_x = 1;
    int dir_y = 0;
    int apple_x = 8;
    int apple_y = 5;
    int score = 0;

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            board[y][x] = 0;
        }
    }

    snake_x[0] = 3;
    snake_y[0] = 5;
    snake_x[1] = 2;
    snake_y[1] = 5;
    snake_x[2] = 1;
    snake_y[2] = 5;
    snake_x[3] = 0;
    snake_y[3] = 5;

    for (;;) {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                board[y][x] = 0;
            }
        }

        for (int i = 0; i < length; i++) {
            if (snake_x[i] >= 0 && snake_x[i] < width && snake_y[i] >= 0 && snake_y[i] < height) {
                board[snake_y[i]][snake_x[i]] = 1;
            }
        }
        board[apple_y][apple_x] = 2;

        terminal_clear();
        terminal_println("LiteOS Snake");
        terminal_write("Score: ");
        terminal_print_dec((u32)score);
        terminal_putc('\n');
        terminal_putc('\n');

        terminal_write("+--------------------+\n");
        for (int y = 0; y < height; y++) {
            terminal_putc('|');
            for (int x = 0; x < width; x++) {
                int cell = board[y][x];
                if (cell == 1) {
                    terminal_putc('#');
                } else if (cell == 2) {
                    terminal_putc('*');
                } else {
                    terminal_putc(' ');
                }
            }
            terminal_putc('|');
            terminal_putc('\n');
        }
        terminal_write("+--------------------+\n");
        terminal_println("The border is dangerous. Q quits.");

        int key = read_key();
        if (key == 0x100 + 1) {
            dir_x = 0; dir_y = -1;
        } else if (key == 0x100 + 2) {
            dir_x = 0; dir_y = 1;
        } else if (key == 0x100 + 3) {
            dir_x = -1; dir_y = 0;
        } else if (key == 0x100 + 4) {
            dir_x = 1; dir_y = 0;
        } else if (key == 'q' || key == 'Q') {
            terminal_println("Snake closed.");
            return;
        }

        for (int i = length - 1; i > 0; i--) {
            snake_x[i] = snake_x[i - 1];
            snake_y[i] = snake_y[i - 1];
        }

        snake_x[0] += dir_x;
        snake_y[0] += dir_y;

        if (snake_x[0] < 0 || snake_x[0] >= width || snake_y[0] < 0 || snake_y[0] >= height) {
            terminal_println("Game over!");
            return;
        }

        if (snake_x[0] == apple_x && snake_y[0] == apple_y) {
            score += 10;
            length++;
            apple_x = (apple_x + 3) % width;
            apple_y = (apple_y + 2) % height;
        }

        for (int i = 1; i < length; i++) {
            if (snake_x[0] == snake_x[i] && snake_y[0] == snake_y[i]) {
                terminal_println("Game over!");
                return;
            }
        }

        for (u32 i = 0; i < 1000000; i++) {
            asm volatile("nop");
        }
    }
}

static void shell_command(const char *line) {
    if (line[0] == '\0') {
        return;
    }

    char cmd[32];
    char arg[128];
    int pos = 0;

    while (line[pos] != '\0' && line[pos] != ' ') {
        cmd[pos] = line[pos];
        pos++;
    }
    cmd[pos] = '\0';

    while (line[pos] == ' ') {
        pos++;
    }
    int arg_pos = 0;
    while (line[pos] != '\0') {
        arg[arg_pos++] = line[pos++];
    }
    arg[arg_pos] = '\0';

    if (strcmp(cmd, "help") == 0) {
        terminal_println("LiteOS commands: help, clear, echo, ls, cat, edit, run, mousetest, snake, about");
    } else if (strcmp(cmd, "clear") == 0) {
        terminal_clear();
    } else if (strcmp(cmd, "echo") == 0) {
        terminal_println(arg);
    } else if (strcmp(cmd, "ls") == 0) {
        print_file_list();
    } else if (strcmp(cmd, "cat") == 0) {
        cat_file(arg);
    } else if (strcmp(cmd, "edit") == 0) {
        if (arg[0] == '\0') {
            terminal_println("Usage: edit filename");
        } else {
            nano_editor(arg);
        }
    } else if (strcmp(cmd, "run") == 0) {
        if (arg[0] == '\0') {
            terminal_println("Usage: run filename");
        } else {
            run_program(arg);
        }
    } else if (strcmp(cmd, "mousetest") == 0) {
        mouse_test();
    } else if (strcmp(cmd, "snake") == 0) {
        snake_game();
    } else if (strcmp(cmd, "about") == 0) {
        terminal_println("LiteOS - simple custom kernel shell with editor and Snake");
    } else {
        terminal_write("Unknown command: ");
        terminal_println(cmd);
    }
}

static void shell_replace_input(const char *text) {
    while (shell_len > 0) {
        terminal_putc('\b');
        terminal_putc(' ');
        terminal_putc('\b');
        shell_len--;
    }

    shell_len = strlen(text);
    if (shell_len > 255) {
        shell_len = 255;
    }
    memcpy(shell_buffer, text, (u32)shell_len);
    shell_buffer[shell_len] = '\0';
    terminal_write(shell_buffer);
}

static void shell_add_history(const char *line) {
    if (line[0] == '\0') {
        return;
    }
    if (shell_history_count < 8) {
        strcpy(shell_history[shell_history_count++], line);
    } else {
        for (int i = 1; i < 8; i++) {
            strcpy(shell_history[i - 1], shell_history[i]);
        }
        strcpy(shell_history[7], line);
    }
    shell_history_index = shell_history_count;
}

static void shell_complete(void) {
    static const char *commands[] = {
        "help", "clear", "echo", "ls", "cat", "edit", "run", "snake", "about"
    };
    const char *match = 0;
    int matches = 0;
    int prefix_start = shell_len;
    while (prefix_start > 0 && shell_buffer[prefix_start - 1] != ' ') {
        prefix_start--;
    }
    int prefix_len = shell_len - prefix_start;

    for (u32 i = 0; i < sizeof(commands) / sizeof(commands[0]); i++) {
        if (strlen(commands[i]) >= prefix_len && strncmp(commands[i], shell_buffer + prefix_start, prefix_len) == 0) {
            match = commands[i];
            matches++;
        }
    }
    for (int i = 0; i < file_count; i++) {
        if (strlen(files[i].name) >= prefix_len && strncmp(files[i].name, shell_buffer + prefix_start, prefix_len) == 0) {
            match = files[i].name;
            matches++;
        }
    }

    if (matches != 1) {
        return;
    }

    char completed[256];
    int completed_len = prefix_start;
    memcpy(completed, shell_buffer, (u32)prefix_start);
    int match_len = strlen(match);
    memcpy(completed + completed_len, match, (u32)match_len);
    completed_len += match_len;
    if (prefix_start == 0) {
        completed[completed_len++] = ' ';
    }
    completed[completed_len] = '\0';
    shell_replace_input(completed);
}

static void shell_loop(void) {
    terminal_write_color("LiteOS shell ready. Type 'help'\n", 0x0B);
    while (1) {
        terminal_write_color("liteos> ", 0x0E);
        shell_len = 0;
        shell_history_index = shell_history_count;
        memset(shell_buffer, 0, sizeof(shell_buffer));

        while (1) {
            int key = read_key();
            if (key == '\n') {
                shell_buffer[shell_len] = '\0';
                terminal_putc('\n');
                shell_add_history(shell_buffer);
                shell_command(shell_buffer);
                break;
            }
            if (key == '\t') {
                shell_complete();
                continue;
            }
            if (key == 0x100 + 1 && shell_history_count > 0) {
                if (shell_history_index > 0) {
                    shell_history_index--;
                    shell_replace_input(shell_history[shell_history_index]);
                }
                continue;
            }
            if (key == 0x100 + 2) {
                if (shell_history_index < shell_history_count - 1) {
                    shell_history_index++;
                    shell_replace_input(shell_history[shell_history_index]);
                } else if (shell_history_index < shell_history_count) {
                    shell_history_index = shell_history_count;
                    shell_replace_input("");
                }
                continue;
            }
            if (key == '\b') {
                if (shell_len > 0) {
                    shell_len--;
                    shell_buffer[shell_len] = '\0';
                    terminal_putc('\b');
                    terminal_putc(' ');
                    terminal_putc('\b');
                }
                continue;
            }
            if (key >= 32 && key < 127 && shell_len < 255) {
                shell_buffer[shell_len++] = (char)key;
                shell_buffer[shell_len] = '\0';
                terminal_putc((char)key);
                shell_history_index = shell_history_count;
            }
        }
    }
}

static void desktop_open_item(const char *name, const char *kind) {
    if (strcmp(kind, "file") == 0) {
        terminal_clear();
        cat_file(name);
        terminal_println("Press any key to return.");
        read_key();
        return;
    }

    if (strcmp(name, "Shell") == 0) {
        shell_loop();
    } else if (strcmp(name, "Files") == 0) {
        terminal_clear();
        print_file_list();
        terminal_println("Press any key to return.");
        read_key();
    } else if (strcmp(name, "LiteNano") == 0) {
        nano_editor("notes.txt");
    } else if (strcmp(name, "Snake") == 0) {
        snake_game();
    } else if (strcmp(name, "Settings") == 0) {
        terminal_clear();
        terminal_println("LiteOS Settings");
        terminal_println("");
        terminal_println("Choose Keyboard GUI theme:");
        terminal_println("1. Brick Classic");
        terminal_println("2. Red Classic");
        terminal_println("3. Blue Steel");
        terminal_println("4. Green Screen");
        terminal_println("5. High Contrast");
        terminal_println("");
        terminal_println("Press 1-5 to apply, or any other key to return.");

        int key = read_key();
        if (key >= '1' && key <= '5') {
            keyboard_gui_set_theme(key - '1');
            terminal_println("Theme applied. Press any key to return.");
            read_key();
        }
    }
}

static void keyboard_gui_start(void) {
    DesktopRuntime runtime = {
        .clear = terminal_clear,
        .write = terminal_write_color,
        .write_at = terminal_write_at,
        .read_key = read_key,
        .poll_key = poll_key,
        .sleep_ticks = timer_sleep,
        .open_item = desktop_open_item
    };
    keyboard_gui_run(&runtime);
}

static void mouse_gui_start(void) {
    terminal_clear();
    terminal_println("Starting experimental mouse GUI...");

    if (!mouse_begin_test()) {
        terminal_println("Mouse not detected or initialization failed.");
        terminal_println("Press any key to return.");
        read_key();
        return;
    }

    terminal_println("Move the mouse to see the cursor update on screen.");
    terminal_println("Press Q to quit.");

    MouseDesktopRuntime runtime = {
        .common = {
            .clear = terminal_clear,
            .write = terminal_write_color,
            .write_at = terminal_write_at,
            .read_key = read_key,
            .poll_key = poll_key,
            .sleep_ticks = timer_sleep,
            .open_item = desktop_open_item
        },
        .poll_mouse = mouse_poll
    };
    mouse_gui_run(&runtime);
    mouse_disable();
}

static void startup_menu(void) {
    while (1) {
        terminal_clear();
        terminal_write_color("==================== LiteOS ====================\n", 0x4F);
        terminal_write_color("\nChoose an interface:\n\n", 0x0E);
        terminal_println("1. Keyboard GUI");
        terminal_println("2. Mouse GUI");
        terminal_println("3. Shell");
        terminal_println("4. Shutdown");
        terminal_write_color("\nPress 1, 2, 3, or 4: ", 0x0B);

        int key = read_key();
        if (key == '1') {
            keyboard_gui_start();
        } else if (key == '2') {
            mouse_gui_start();
        } else if (key == '3') {
            shell_loop();
            return;
        } else if (key == '4') {
            terminal_println("LiteOS stopped. You can power off the computer.");
            asm volatile("cli");
            while (1) {
                asm volatile("hlt");
            }
        }
    }
}

void kernel_main(void) {
    terminal_clear();
    timer_init();
    init_filesystem();
    usb_keyboard_init();
    terminal_write_color("Booting LiteOS...\n", 0x0B);
    terminal_write_color("Custom kernel loaded.\n", 0x0A);
    terminal_write_color("Keyboard ready. Timer online.\n", 0x0A);
    startup_menu();
}
